import axios from 'axios';

function getApi(request) {
  return axios(request)
  .then((response) => {
    return response;
  })
  .catch((error) => {
    return error.response;
  });
}

export default {
  getApi
};