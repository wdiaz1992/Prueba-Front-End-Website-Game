import React from "react";
//Configs
import Routes from "configs/Routes/Routes";

function App(props = {}) {
  return (
    <Routes />
  );
}

export default App;