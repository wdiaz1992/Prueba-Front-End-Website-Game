import React, {useState,useEffect,useRef,useCallback} from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import {Container,Row,Col,Image,Card,Alert,CardGroup,Modal} from 'react-bootstrap';
//Actions
import { getInfo } from "actions/gaming";
//Request
import request from "requests/request";
//Components
import Menu from "components/Menu/Menu";
import Loader from "components/Loader/Loader";
//utils
import {redirect} from "utils/utils";
//Styles
import "./Home.css";

Home.propTypes = {
  dispatch: PropTypes.func,
  gaming: PropTypes.object
};

function Home(props = {}){
  const [loader, setLoader] = useState(true);
  const [show, setShow] = useState(false);
  const [dataPlayer, setDataPlayer] = useState({});
  const [error,setError] = useState(false);
  const [messageError,setMessageError] = useState("");

  const redirectUrl = useCallback(async () => {
    const {gaming} = props;

    const url = gaming && gaming.data && gaming.data.header && gaming.data.header.bannerUrl && gaming.data.header.bannerUrl;
    const newWindowBanner = gaming && gaming.data && gaming.data.header && gaming.data.header.newWindowBanner && gaming.data.header.newWindowBanner;

    redirect(newWindowBanner,url);
  });

  const redirectUrlPlayer = useCallback(async (url) => {
    redirect(true,url);
  });

  const handleClose  = useCallback(async () => {
    setDataPlayer({});
    setShow(false);
  });

  const handleShow  = useCallback(async (data) => {
    setDataPlayer(data);
    setShow(true);
  });


  useEffect(() => {
    const {dispatch} = props;

    const data = request.requestGET();
    dispatch(getInfo(data));
  },[]);

  const prevGaming= useRef(props.gaming);
  useEffect(() => {
    const {gaming} = props;

    if(prevGaming.current != gaming && gaming.ended){
      if(!gaming.isError){

        let validate = true;
        let message = "";


        if(gaming.data.credenciales && !gaming.data.credenciales.user){
          validate = false;
          message = "Usuario Invalido";
        }

        //Validando Password
        const password = gaming.data.credenciales && gaming.data.credenciales.password;

        if(password.length < 8){
          validate = false;
          message = "Contraseña Incorrecta. La contraseña debe de contener un minimo de 8 caracteres.";
        }

        if(!validate){
          setError(!validate);
          setMessageError(message);
        }

        setLoader(false);
      }
    }

    prevGaming.current = gaming;
  },[props.gaming]);

  function render(){
    const {gaming} = props;

    const banner = gaming && gaming.data && gaming.data.header && gaming.data.header.bannerImg && gaming.data.header.bannerImg;
    const title = gaming && gaming.data && gaming.data.header && gaming.data.header.tituloBienvenida && gaming.data.header.tituloBienvenida;
    const fontSizeTitle = gaming && gaming.data && gaming.data.header && gaming.data.header.tituloFontSize && gaming.data.header.tituloFontSize;
    const colorTitle = gaming && gaming.data && gaming.data.header && gaming.data.header.tituloColor && gaming.data.header.tituloColor;

    return !loader && !error ? (
      <div>
        <Menu
          header={gaming && gaming.data && gaming.data.header && gaming.data.header}
        />
        <button className="button-banner" onClick={() => redirectUrl}>
          <Image className="banner" src={banner} fluid />
        </button>
        <Container className="contentHome">
          <h1 style={{fontSize: `${fontSizeTitle}px`,color:colorTitle}}>{title}</h1>
          <Container className="contentGroup">
              {
                gaming &&
                gaming.data &&
                gaming.data.body &&
                gaming.data.body.map((item,key) => {
                  const fontSizeTeam = item && item.teamFontSize && item.teamFontSize;
                  const colorTeam = item && item.teamColor && item.teamColor;

                  return (
                    <Row className="contenTeam">
                      <Col xs="12">
                      <h1 style={{fontSize: `${fontSizeTeam}px`,color:colorTeam}}>{item.nombreTeam}</h1>
                      </Col>
                      <Col xs="12">
                        <CardGroup>
                          {
                            item && item.players && item.players.map((player,k) => {
                              if(key !== 4){
                                return (
                                  <Card bg="dark">
                                    <Card.Body>
                                      <button onClick={() => handleShow(player)}>
                                        <Card.Img variant="top" src={player.playerImg} />
                                      </button>
                                    </Card.Body>
                                  </Card>
                                )
                              }
                            })
                          }
                        </CardGroup>
                      </Col>
                    </Row>
                  )
                })
              }
          </Container>
          {modal()}
        </Container>
      </div>
    ) :
    (
      !error ?
        <Loader />
      : 
      (
        <div className="contentError">
          <Alert variant="danger">
            <Alert.Heading>¡Error!</Alert.Heading>
            <p>{messageError}</p>
          </Alert>
        </div>
      )
    )
  }

  function modal(){
    const name = dataPlayer && dataPlayer.playerNombre;
    const apellido = dataPlayer && dataPlayer.playerApellido;
    const avatar = dataPlayer && dataPlayer.playerImg;
    const edad = dataPlayer && dataPlayer.playerEdad;
    const pasaTiempo = dataPlayer && dataPlayer.playerPasatiempo;
    const website = dataPlayer && dataPlayer.playerWebSite;
    const profesion = dataPlayer && dataPlayer.playerProfesion;
    const url = dataPlayer && dataPlayer.playerImgUrl;

    return (
      <>  
        <Modal
          show={show}
          onHide={handleClose}
          animation={true}
          aria-labelledby="contained-modal-title-vcenter"
          centered
          className="contenModal"
        >
          <Modal.Header closeButton>
            <Modal.Title>{`${name} ${apellido}`}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Row>
              <Col>
                <button onClick={() => redirectUrlPlayer(url)}><Image src={avatar} thumbnail/></button>
              </Col>
              <Col>
                <Row className="contentProfile">
                  <Col>Edad:</Col>
                  <Col>{edad}</Col>
                </Row>
                <Row className="contentProfile">
                  <Col>Pasatiempo:</Col>
                  <Col>{pasaTiempo}</Col>
                </Row>
                <Row className="contentProfile">
                  <Col>Website:</Col>
                  <Col>{website}</Col>
                </Row>
                <Row className="contentProfile">
                  <Col>Prefesion:</Col>
                  <Col>{profesion}</Col>
                </Row>
              </Col>
            </Row>
          </Modal.Body>
        </Modal>
      </>
    );
  }

  return render();
}

export default connect(state => {
  return {
    gaming: state.gaming.get("gaming")
  };
}, null)(Home);