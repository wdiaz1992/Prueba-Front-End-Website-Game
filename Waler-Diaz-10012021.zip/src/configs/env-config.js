export const configs = {
  apiUrls: {
    SERVER_GAMING: "https://private-5c614-pathnames.apiary-mock.com/svc-gaming"
  }
}