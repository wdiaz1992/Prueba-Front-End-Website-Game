import React from "react";
import {Switch, Route } from "react-router-dom";
import PropTypes from "prop-types";
//Views
import Home from "views/Home/";

Routes.propTypes = {
  dispatch: PropTypes.func,
  paths: PropTypes.object
};

function Routes(props = {}){

  return (
    <Switch>
      <Route exact path="/" component={Home} />
    </Switch>
  )
}

export default Routes;