import React,{useCallback} from "react";
import PropTypes from "prop-types";
import {Navbar} from 'react-bootstrap';
//Utils
import {redirect} from "utils/utils";
//Styles
import "./Menu.css";

Menu.propTypes = {
  header: PropTypes.object
};

function Menu(props = {}){
  const redirectUrl = useCallback(async () => {
    const {header} = props;

    const url = header && header.logoURL && header.logoURL;
    const newWindowLogo = header && header.logoURL && header.newWindowLogo;

    redirect(newWindowLogo,url);
  });


  function render(){
    const {header} = props;
    
    const nombre = header && header.logoImg && header.nombre;
    const logo = header && header.logoImg && header.logoImg;

    return (
      <Navbar collapseOnSelect expand="sm"  bg="dark" variant="dark" sticky="top">
        <Navbar.Brand href="/">{nombre}</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav" className="justify-content-end">
          <button onClick={() => redirectUrl}>
            <img
              src={logo}
              width="60"
              height="60"
              className="d-inline-block align-top img-responsive"
              alt="Gaming Logo"
            />
          </button>
        </Navbar.Collapse>
      </Navbar>
    );
  }

  return render();
}

export default Menu;