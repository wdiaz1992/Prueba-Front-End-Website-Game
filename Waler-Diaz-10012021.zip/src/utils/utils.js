import { createBrowserHistory } from "history";
const history = createBrowserHistory();

export function redirect(val,url){
  if(val && url !== ""){
    window.open(url, '_blank');
  }else{
    history.push("/");
  }
}