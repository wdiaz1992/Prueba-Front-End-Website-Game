import { Map } from "immutable";

import {
  GET_SERVER_GAMING_ACTION_START,
  GET_SERVER_GAMING_ACTION_ERROR,
  GET_SERVER_GAMING_ACTION_SUCCESS
} from "actions/gaming";

const initialState = Map({
  gaming: {
    isError: false,
    ended: false,
    data: null
  }
});

const actionsMap = {
  [GET_SERVER_GAMING_ACTION_START]: state => {
    return state.merge(
      Map({
        gaming: {
          ended: false,
          isError: false,
          data: null
        }
      })
    );
  },
  [GET_SERVER_GAMING_ACTION_ERROR]: (state, action) => {
    return state.merge(
      Map({
        gaming: {
          ended: true,
          isError: true,
          data: action.error
        }
      })
    );
  },
  [GET_SERVER_GAMING_ACTION_SUCCESS]: (state, action) => {
    return state.merge(
      Map({
        gaming: {
          ended: true,
          isError: false,
          data: action.data
        }
      })
    );
  }
};

export default function reducer(state = initialState, action = {}) {
  const fn = actionsMap[action.type];
  return fn ? fn(state, action) : state;
}