import { combineReducers } from 'redux'

//Reducers Files
import gaming from "./gaming";

const rootReducer = combineReducers({
  gaming
});

export default rootReducer