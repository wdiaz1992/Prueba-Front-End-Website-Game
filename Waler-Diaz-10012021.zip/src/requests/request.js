import { configs } from "configs/env-config";

const request = {
    requestGET: function() {

      const data = {
        method: "GET",
        headers: {
          Accept: "application/json",
          ["Content-Type"]: "application/json",
        },
        url: configs.apiUrls.SERVER_GAMING
      }
      
      return data;
    }
  };
  
  export default request;