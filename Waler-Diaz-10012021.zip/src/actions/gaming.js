import api from "api/api";

export const GET_SERVER_GAMING_ACTION_START = "GET_SERVER_GAMING_ACTION_START";
export const GET_SERVER_GAMING_ACTION_ERROR = "GET_SERVER_GAMING_ACTION_ERROR";
export const GET_SERVER_GAMING_ACTION_SUCCESS = "GET_SERVER_GAMING_ACTION_SUCCESS";

function getStart(){
  return {
    type: GET_SERVER_GAMING_ACTION_START
  }
}

function getError(error){
  return {
    type: GET_SERVER_GAMING_ACTION_ERROR,
    error
  }
}

function getSuccess(data){
  return {
    type: GET_SERVER_GAMING_ACTION_SUCCESS,
    data
  }
}

export function getInfo(request) {
  return function(dispatch) {
    dispatch(getStart());

    api.getApi(request)
    .then(response => {
      const statusReq = response.status;
      
      if (statusReq === 200 || statusReq === 202) {
        return response.data;
      } else {
        dispatch(getError({error: null}));
        return false;
      }
    })
    .then(data => {
      if (data) {
        dispatch(getSuccess(data));
      }else{
        dispatch(getError({error: null}));
      }
    })
    .catch(error => {
      dispatch(getError({error}));
    });
  };
}
